# YuvaIntern Week 1 – RESTful Task Manager API

A RESTful Task Manager API built with Node.js and Express.js for the YuvaIntern Junior NodeJS Developer internship.

## Features
- CRUD operations for tasks
- Express routing
- JSON request/response handling
- Request logging middleware
- Input validation
- 404 and centralized 500 error handling
- Persistent local JSON storage
- Postman collection
- Automated API test script

## Run
Requirements: Node.js 18+

```bash
npm install
npm start
```

API base URL: `http://localhost:3000`

## Endpoints
- GET `/api/tasks` – list all tasks
- GET `/api/tasks/:id` – get one task
- POST `/api/tasks` – create a task
- PUT `/api/tasks/:id` – update a task
- DELETE `/api/tasks/:id` – delete a task

Example POST body:
```json
{
  "title": "Complete YuvaIntern task",
  "description": "Build REST API",
  "dueDate": "2026-10-10",
  "status": "pending"
}
```

Run tests with the server active:
```bash
npm test
```

The project uses a JSON file as a lightweight storage layer so it can run without database credentials.
