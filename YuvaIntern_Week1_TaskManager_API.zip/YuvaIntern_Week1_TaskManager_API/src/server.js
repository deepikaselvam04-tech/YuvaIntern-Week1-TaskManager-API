const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, '..', 'data', 'tasks.json');

app.use(express.json());

// Request logging middleware
app.use((req, res, next) => {
  const started = Date.now();
  res.on('finish', () => {
    console.log(`${req.method} ${req.originalUrl} ${res.statusCode} - ${Date.now() - started}ms`);
  });
  next();
});

function ensureDataFile() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '[]', 'utf8');
}
function readTasks() {
  ensureDataFile();
  return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
}
function writeTasks(tasks) {
  ensureDataFile();
  fs.writeFileSync(DATA_FILE, JSON.stringify(tasks, null, 2), 'utf8');
}
function validateTask(body, partial = false) {
  const errors = [];
  if (!partial || body.title !== undefined) {
    if (typeof body.title !== 'string' || body.title.trim().length < 2)
      errors.push('title must be a string with at least 2 characters');
  }
  if (!partial || body.description !== undefined) {
    if (typeof body.description !== 'string')
      errors.push('description must be a string');
  }
  if (body.status !== undefined && !['pending','in-progress','completed'].includes(body.status))
    errors.push('status must be pending, in-progress, or completed');
  if (body.dueDate !== undefined && body.dueDate !== null && Number.isNaN(Date.parse(body.dueDate)))
    errors.push('dueDate must be a valid date string or null');
  return errors;
}

app.get('/api/tasks', (req, res) => {
  const tasks = readTasks();
  res.json({ success: true, count: tasks.length, data: tasks });
});

app.get('/api/tasks/:id', (req, res) => {
  const task = readTasks().find(t => t.id === req.params.id);
  if (!task) return res.status(404).json({ success: false, message: 'Task not found' });
  res.json({ success: true, data: task });
});

app.post('/api/tasks', (req, res) => {
  const errors = validateTask(req.body);
  if (errors.length) return res.status(400).json({ success: false, errors });
  const tasks = readTasks();
  const now = new Date().toISOString();
  const task = {
    id: crypto.randomUUID(),
    title: req.body.title.trim(),
    description: req.body.description.trim(),
    dueDate: req.body.dueDate || null,
    status: req.body.status || 'pending',
    createdAt: now,
    updatedAt: now
  };
  tasks.push(task);
  writeTasks(tasks);
  res.status(201).json({ success: true, message: 'Task created successfully', data: task });
});

app.put('/api/tasks/:id', (req, res) => {
  const errors = validateTask(req.body, true);
  if (errors.length) return res.status(400).json({ success: false, errors });
  const tasks = readTasks();
  const index = tasks.findIndex(t => t.id === req.params.id);
  if (index === -1) return res.status(404).json({ success: false, message: 'Task not found' });
  const old = tasks[index];
  tasks[index] = {
    ...old,
    ...(req.body.title !== undefined ? { title: req.body.title.trim() } : {}),
    ...(req.body.description !== undefined ? { description: req.body.description.trim() } : {}),
    ...(req.body.dueDate !== undefined ? { dueDate: req.body.dueDate } : {}),
    ...(req.body.status !== undefined ? { status: req.body.status } : {}),
    updatedAt: new Date().toISOString()
  };
  writeTasks(tasks);
  res.json({ success: true, message: 'Task updated successfully', data: tasks[index] });
});

app.delete('/api/tasks/:id', (req, res) => {
  const tasks = readTasks();
  const index = tasks.findIndex(t => t.id === req.params.id);
  if (index === -1) return res.status(404).json({ success: false, message: 'Task not found' });
  const deleted = tasks.splice(index, 1)[0];
  writeTasks(tasks);
  res.json({ success: true, message: 'Task deleted successfully', data: deleted });
});

app.use((req, res) => res.status(404).json({ success: false, message: 'Route not found' }));
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: 'Internal server error' });
});

if (require.main === module) {
  app.listen(PORT, () => console.log(`Task Manager API running on port ${PORT}`));
}
module.exports = app;
