const assert = require('assert');
const BASE = 'http://localhost:3000/api/tasks';

async function request(url, options = {}) {
  const response = await fetch(url, {
    headers: { 'Content-Type': 'application/json' }, ...options
  });
  return { status: response.status, body: await response.json() };
}

(async () => {
  let r = await request(BASE, {
    method: 'POST',
    body: JSON.stringify({ title: 'Test task', description: 'API test', status: 'pending' })
  });
  assert.strictEqual(r.status, 201);
  const id = r.body.data.id;

  r = await request(`${BASE}/${id}`);
  assert.strictEqual(r.status, 200);

  r = await request(`${BASE}/${id}`, {
    method: 'PUT', body: JSON.stringify({ status: 'completed' })
  });
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.body.data.status, 'completed');

  r = await request(`${BASE}/${id}`, { method: 'DELETE' });
  assert.strictEqual(r.status, 200);

  r = await request(`${BASE}/does-not-exist`);
  assert.strictEqual(r.status, 404);

  console.log('All API tests passed.');
})().catch(err => { console.error(err); process.exit(1); });
